package dieRolling;

import java.util.ArrayList;

public class DieRoll {
  //  protected int[] numbers = {1};
  //  protected int[] faces = {4};
    protected ArrayList<Integer> numbers = new ArrayList<Integer>();
    protected ArrayList<Integer> faces = new ArrayList<Integer>();
    public DieRoll(){ }

    public DieRoll(int inNum, int inFaces){
        numbers.add(inNum);
        faces.add(inFaces);
    }
    public DieRoll(int[] inNums, int[] inFaces){
        for(int i : inNums)
            numbers.add(i);
        for(int i : inFaces)
            faces.add(i);
    }

    public int getOutput(){
        int sum = 0;
        for(int i = 0; i < numbers.size(); i++){
            sum += DieRolling.rollDice(faces.get(i), numbers.get(i));
        }
        return sum;
    }

    public void addDie(int dieNum, int dieFace){
        numbers.add(dieNum);
        faces.add(dieFace);
    }

    public String toString(){
        String end = "";
        for(int i = 0; i < numbers.size(); i++){
            end += numbers.get(i) + "d" + faces.get(i);
            if(i != numbers.size() - 1){
                end += " + ";
            }
        }
        return end;
    }
}
