package dieRolling;

public class DieRolling {
    public static int rollDice(int dieValue, int dieNumber, int modifier){
        return rollDice(dieValue, dieNumber) + modifier*dieNumber;
    }
    public static int rollDice(int dieValue, int dieNumber){
        int total = 0;
        int decrement = dieNumber;
        while(decrement > 0){
            total += rollDie(dieValue);
            decrement--;
        }
        return total;
    }
    public static int rollDie(int dieValue, int modifier){
        return rollDie(dieValue) + modifier;
    }
    public static int rollDie(int dieValue){
        return (int)(Math.random() * dieValue) + 1;
    }
    public static int[] rollDieArray(int dieValue, int dieNumber, int modifier){
        int[] total = new int[dieNumber];
        for(int i = 0; i < dieNumber; i++) {
            total[i] = rollDie(dieValue, modifier);
        }
        return total;
    }
    public static int[] rollDieArray(int dieValue, int dieNumber){
        int[] total = new int[dieNumber];
        for(int i = 0; i < dieNumber; i++) {
            total[i] = rollDie(dieValue);
        }
        return total;
    }
    public static int pureRandom(int upperBound){
        return (int)(Math.random() * upperBound+1);
    }
    public static int pureRandom(int upperBound, int lowerBound){
        return (int)(Math.random() * (upperBound-lowerBound+1)) + lowerBound;
    }
}
