package items;

public class Item {
    protected String name = "";
    protected String desc = "";
    protected String attributes = "";
    protected int cost = 0;

    public Item(){ }
    public Item(String inName, String inDesc){
        name = inName;
        desc = inDesc;
    }
    public Item(String inName, String inDesc, String inAttributes){
        name = inName;
        desc = inDesc;
        attributes = inAttributes;
    }

    public String getName(){
        return name;
    }
    public void setName(String newName){
        name = newName;
    }
    public String getDesc(){
        return desc;

    }
    public void setDesc(String newDesc){
        desc = newDesc;
    }
    public void addDesc(String addDesc){
        desc += "\n" + addDesc;
    }
    public String getAttributes(){
        return attributes;
    }
    public void setAttributes(String newAtts){
        attributes = newAtts;
    }
    public void addAttributes(String addAtts){
        attributes += "\n" + addAtts;
    }

    public int getCost(){
        return cost;
    }
    public void setCost(int newCost){
        cost = newCost;
    }

    public String toString(){
        String end = "";
        end += "Name: " + name + "\n" +
                "Description:\n" + desc + "\n";
        if(!attributes.equals(""))
            end += "Attributes: \n" + attributes + "\n";
        if(cost != 0)
            end += "Cost: "  + cost + "\n";
        return end;
    }


}
