package items;

public class Armor extends Item {
    //TODO: AC, Max. dex modifier, toString()
}
