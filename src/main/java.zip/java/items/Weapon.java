package items;
import dieRolling.*;

import java.util.ArrayList;

public class Weapon extends Item {
    protected ArrayList<Attack> attacks = new ArrayList<>();
    public Weapon(){
        super();
    }

    public Weapon(String inName, String inDesc, Attack inAttack){
        super(inName, inDesc);
        attacks.add(inAttack);
    }
    public Weapon(String inName, String inDesc, Attack[] inAttack){
        super(inName, inDesc);
        for(Attack a : inAttack)
            attacks.add(a);
    }

    public Weapon(String inName, String inDesc, String inAtts, Attack inAttack){
        super(inName, inDesc, inAtts);
        attacks.add(inAttack);
    }
    public Weapon(String inName, String inDesc, String inAtts, Attack[] inAttack){
        super(inName, inDesc, inAtts);
        for(Attack a : inAttack)
            attacks.add(a);
    }

    public int getDamage(int attackNum){
        attackNum--;
        if(attackNum < attacks.size())
            return attacks.get(attackNum).getOutput();
        else
            return 0;
    }
    public String getAttack(int attackNum){
        attackNum--;
        if(attackNum < attacks.size())
            return "Attack with " + name + "\n" + attacks.get(attackNum).getAttack();
        else
            return "No such attack.";
    }

    public String toString(){
        String end = "";
        end += "Name: " + name + "\n" +
                "Description:\n" + desc + "\n";
        if(!attributes.equals(""))
            end += "Attributes: \n" + attributes + "\n";
        if(!attacks.isEmpty()){
            end += "Attacks: \n";
            int curAtt = 1;
            for(int i = 0; i < attacks.size(); i++)
                end += curAtt++ + ": " + attacks.get(i).toString() + "\n";
        }
        if(cost != 0)
            end += "Cost: "  + cost + "\n";
        return end;
    }
}
