package enchants;

public interface Enchantment {
    public void enchEffec();
    public void detEnchEffec(int power);
}
