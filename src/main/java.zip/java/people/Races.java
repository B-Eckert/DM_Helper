package people;

import dieRolling.DieRolling;
import tools.General;

public class Races {
    public static final String[] NORMAL_RACES = {"Human", "Elf", "Dwarf", "Halfling", "Dragonborn", "Gnome", "Half-Elf", "Half-Orc"};           //t0
    public static final String[] EXOTIC_RACES = {"Tiefling", "Kenku", "Aaracokra", "Tabaxi", "Triton", "Goliath", "Minotaur", "Lizardfolk"};    //t1
    public static final String[] RARE_RACES = {"Deep Gnome", "Firbolg","Centaur","Loxodon", "Gith", "Tortle", "Grung", "Vedalken"};                                            //t2
    public static final String[] MONSTROUS_RACES = {"Bugbear", "Goblin", "Orc", "Hobgoblin", "Kobold", "Yuan-Ti Pureblood"};                    //t3
    public static final String[] MAGICAL_RACES = {"Genasi", "Aasimar", "Simic Hybrid", "Changeling", "Shifter", "Kalashtar"};                                //t4
    public static final String[] IMPOSSIBLE_RACES = {"Warforged"};                                                                              //t5

    public static boolean[] genTiers(boolean normal, boolean exotic, boolean rare, boolean monstrous, boolean magical, boolean impossible){
        boolean end[] = new boolean[6];
        end[0] = normal;
        end[1] = exotic;
        end[2] = rare;
        end[3] = monstrous;
        end[4] = magical;
        end[5] = impossible;
        return end;
    }
    public static String randomRace(boolean[] tiers){
        String[] racePool = {};
        if(tiers[0])
            racePool = General.mergeStringArrays(racePool, NORMAL_RACES);
        if(tiers[1])
            racePool = General.mergeStringArrays(racePool, EXOTIC_RACES);
        if(tiers[2])
            racePool = General.mergeStringArrays(racePool, RARE_RACES);
        if(tiers[3])
            racePool = General.mergeStringArrays(racePool, MONSTROUS_RACES);
        if(tiers[4])
            racePool = General.mergeStringArrays(racePool, MAGICAL_RACES);
        if(tiers[5])
            racePool = General.mergeStringArrays(racePool, IMPOSSIBLE_RACES);
        String race = "";
        race = racePool[DieRolling.pureRandom(racePool.length) - 1];
        return race;
    }

    public static int[] racialBonuses(String race){
        int[] statLine = new int[6];
        if(race.equals("Aaracokra"))
            statLine = new int[]{0, 2, 0, 1, 0, 0};
        if(race.equals("Aasimar"))
            statLine = new int[]{0, 0, 0, 0, 0, 2};
        if(race.equals("Bugbear"))
            statLine = new int[]{2, 1, 0, 1, 0, 0};
        if(race.equals("Centaur"))
            statLine = new int[]{2, 0, 0, 1, 0, 0};
        if(race.equals("Changeling"))
            statLine = new int[]{0, 1, 0, 0, 0, 2};
        if(race.equals("Dragonborn"))
            statLine = new int[]{2, 0, 0, 0, 0, 1};
        if(race.equals("Dwarf"))
            statLine = new int[]{0, 0, 2, 0, 0, 0};
        if(race.equals("Elf"))
            statLine = new int[]{0, 2, 0, 0, 0, 0};
        if(race.equals("Genasi"))
            statLine = new int[]{0, 0, 2, 0, 0, 0};
        if(race.equals("Gith"))
            statLine = new int[]{0, 0, 0, 0, 1, 0};
        if(race.equals("Gnome"))
            statLine = new int[]{0, 0, 0, 0, 2, 0};
        if(race.equals("Goblin"))
            statLine = new int[]{0, 2, 1, 0, 0, 0};
        if(race.equals("Grung"))
            statLine = new int[]{0, 2, 1, 0, 0, 0};
        if(race.equals("Half-Elf"))
            statLine = new int[]{1, 1, 0, 0, 0, 2};
        if(race.equals("Half-Orc"))
            statLine = new int[]{2, 0, 1, 0, 0, 0};
        if(race.equals("Hobgoblin"))
            statLine = new int[]{0, 0, 2, 0, 1, 0};
        if(race.equals("Human"))
            statLine = new int[]{1, 1, 1, 1, 1, 1};
        if(race.equals("Kalashtar"))
            statLine = new int[]{0, 0, 0, 2, 0, 1};
        if(race.equals("Kenku"))
            statLine = new int[]{0, 2, 0, 1, 0, 0};
        if(race.equals("Kobold"))
            statLine = new int[]{-2, 2, 0, 0, 0, 0};
        if(race.equals("Lizardfolk"))
            statLine = new int[]{0, 0, 2, 1, 0, 0};
        if(race.equals("Loxodon"))
            statLine = new int[]{0, 0, 2, 1, 0, 0};
        if(race.equals("Minotaur"))
            statLine = new int[]{2, 0, 1, 0, 0, 0};
        if(race.equals("Orc"))
            statLine = new int[]{2, 0, 1, 0, -2, 0};
        if(race.equals("Simic Hybrid"))
            statLine = new int[]{1, 0, 2, 0, 0, 0};
        if(race.equals("Tabaxi"))
            statLine = new int[]{0, 2, 0, 0, 0, 1};
        if(race.equals("Tiefling"))
            statLine = new int[]{0, 0, 0, 0, 1, 2};
        if(race.equals("Tortle"))
            statLine = new int[]{2, 0, 0, 1, 0, 0};
        if(race.equals("Triton"))
            statLine = new int[]{1, 0, 1, 0, 0, 1};
        if(race.equals("Vedalken"))
            statLine = new int[]{0, 0, 0, 1, 2, 0};
        if(race.equals("Warforged"))
            statLine = new int[]{1, 0, 2, 0, 0, 0};
        if(race.equals("Yuan-Ti Pureblood"))
            statLine = new int[]{0, 0, 0, 0, 1, 2};
        return statLine;
    }

}
