package people;

public class Stats {
    public static final String[] STAT_NAMES = {"Strength", "Dexterity", "Constitution", "Wisdom", "Intelligence", "Charisma"};
    public static final String[] STAT_ABBREVIATIONS = {"STR","DEX","CON","WIS","INT","CHA"};
    public static int statBonusCalc(int stat){
        return (int)Math.floor(((double)stat - 10.0) / 2.0);
    }
    public static int stringToIndex(String stat){
        for(int i = 0; i < STAT_NAMES.length; i++){
            if(stat.equals(STAT_NAMES[i]) || stat.equals(STAT_ABBREVIATIONS[i])){
                return i;
            }
        }
        return -1;
    }
}
