package people;

import dieRolling.DieRolling;
import people.Races;
import people.Skills;
import people.Stats;
import tools.General;

import java.util.ArrayList;

public class NPC {
    protected String name = "Defaulto", desc = "Default Dude", race = "Human", type = "Classless"; //type = class
    protected int stats[] = {0, 0, 0, 0, 0, 0}; //STR - DEX - CON - WIS - INT - CHA
    protected int bonuses[] = {0, 0, 0, 0, 0, 0};
    protected int profBonus = 1, level = 0;
    protected ArrayList<String> profs = new ArrayList<>();
    //random stat dudes
    public NPC(){
        randomStats();
        boolean[] defTiers = {true, true, false, false, false, false};
        randomRace(defTiers);
        randomProfs(7);
    }
    public NPC(String inName){
        this();
        name = inName;
    }
    public NPC(String inName, String inDesc){
        this(inName);
        desc = inDesc;
    }
    public NPC(String inName, String inDesc, String inType){
        this(inName,inDesc);
        type = inType;
    }
    public NPC(String inName, String inDesc, String inType, String inRace){
        this(inName,inDesc,inType);
        setRace(inRace);
    }

    //known stat dudes
    public NPC(String inName, int[] inStats){
        name = inName;
        stats = inStats;
        calcStatBonuses();
    }
    public NPC(String inName, String inRace, int[] inStats){
        this(inName,inStats);
        setRace(inRace);
    }
    public NPC(String inName, String inRace, String inType, int[] inStats){
        this(inName, inRace, inStats);
        type = inType;
    }
    public NPC(String inName, String inRace, String inType, String inDesc, int[] inStats){
        this(inName,inRace,inType,inStats);
        desc = inDesc;
    }

    public void randomStats(){
        int[][] statArrays = new int[6][4];
        for(int i = 0; i < 6; i++){
            statArrays[i] = DieRolling.rollDieArray(6, 4);
        }
        for(int i = 0; i < statArrays.length; i++){
            int min = statArrays[i][0];
            int rowSum = 0;
            for(int j = 0; j < statArrays[i].length; j++){
                if(min > statArrays[i][j])
                    min = statArrays[i][j];
                rowSum+=statArrays[i][j];
            }
            stats[i] = rowSum - min;
        }
        int[] raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] += raceBonus[i];
        }
        calcStatBonuses();
    }
    public void randomStatsIncompetent(){
        int[][] statArrays = new int[6][3];
        for(int i = 0; i < 6; i++){
            statArrays[i] = DieRolling.rollDieArray(6, 3);
        }
        for(int i = 0; i < statArrays.length; i++){
            int min = statArrays[i][0];
            int rowSum = 0;
            for(int j = 0; j < statArrays[i].length; j++){
                if(min > statArrays[i][j])
                    min = statArrays[i][j];
                rowSum+=statArrays[i][j];
            }
            stats[i] = rowSum - min;
        }
        int[] raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] += raceBonus[i];
        }
        calcStatBonuses();
    }
    public void randomStatsPowerful(){
        int[][] statArrays = new int[6][5];
        for(int i = 0; i < 6; i++){
            statArrays[i] = DieRolling.rollDieArray(6, 5);
        }
        for(int i = 0; i < statArrays.length; i++){
            int min = statArrays[i][0];
            int rowSum = 0;
            for(int j = 0; j < statArrays[i].length; j++){
                if(min > statArrays[i][j])
                    min = statArrays[i][j];
                rowSum+=statArrays[i][j];
            }
            stats[i] = rowSum - min;
        }
        int[] raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] += raceBonus[i];
        }
        calcStatBonuses();
    }
    public void calcStatBonuses(){
        for(int i = 0; i < stats.length; i++){
            bonuses[i] = Stats.statBonusCalc(stats[i]);
        }
    }

    public void randomProfs(int maxPossible){
        int profNum = DieRolling.pureRandom(maxPossible);
        while(profNum > 0){
            String potSkill = Skills.SKILLS[DieRolling.pureRandom(Skills.SKILLS.length-1)];
            if(profs.indexOf(potSkill) == -1)
                profs.add(potSkill);
            else
                profNum++;
            profNum--;
        }
    }

    public void learnSkill(String skill){
        if(General.exists(skill, Skills.SKILLS_AND_SAVES)){
            if(profs.indexOf(skill) == -1){
                profs.add(skill);
            }
        }
    }

    public int statCheck(String skill){
        int mod = 0;
        if(General.exists(skill, Skills.SKILLS_AND_SAVES)){
            if(profs.indexOf(skill) != -1){
                mod += profBonus;
            }
            mod += bonuses[Stats.stringToIndex(Skills.SKILLS_AND_SAVES_ATTS[General.indexOf(skill, Skills.SKILLS_AND_SAVES)])];
        }
        return DieRolling.rollDie(20, mod);
    }
    public void randomRace(boolean[] tiers){
        int[] raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] -= raceBonus[i];
        }
        race = Races.randomRace(tiers);
        raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] += raceBonus[i];
        }
        calcStatBonuses();
    }
    public void setRace(String inRace){
        int[] raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] -= raceBonus[i];
        }
        race = inRace;
        raceBonus = Races.racialBonuses(race);
        for(int i = 0; i < stats.length; i++){
            stats[i] += raceBonus[i];
        }
        calcStatBonuses();
    }

    public String getRace(){
        return race;
    }
    public String getDesc(){
        return desc;
    }
    public void setDesc (String nDesc){
        desc = nDesc;
    }
    public String getType(){
        return type;
    }
    public void setType(String nType) {
        type = nType;
    }
    public String getName(){
        return name;
    }
    public void setName(String nName){
        name = nName;
    }
    public String toString(){
        String end = "";
        end+="Name: " + name + "\nDesc: " + desc + "\nRace: " + race + "\nClass: " + type;
        for(int i = 0; i < stats.length; i++){
            if(i%2 == 0)
                end += "\n";
            else
                end += "\t";
            end+= Stats.STAT_ABBREVIATIONS[i] + ": " + stats[i] + "\tBonus: " + bonuses[i];
        }
        if(!profs.isEmpty()) {
            end+="\nProficiencies: ";
            for(int i = 0; i < profs.size(); i++){
                end+= profs.get(i);
                if(i != profs.size()-1)
                    end+=",";
                end+= " ";
                if(i % 4 == 3){
                    end+="\n";
                }
            }
        }
        return end;
    }
}
