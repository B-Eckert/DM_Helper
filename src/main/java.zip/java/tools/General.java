package tools;

public class General {
    public static int[] mergeIntArrays(int[] n, int[] f){
        int[] q = new int[n.length + f.length];
        int numDiff = 0;
        if(n.length > 0) {
            for (int i = 0; i < n.length; i++) {
                q[i] = n[i];
            }
            numDiff = n.length;
        }
        if(f.length > 0) {
            for (int i = 0; i < f.length; i++) {
                q[i + numDiff] = f[i];
            }
        }
        return q;
    }
    public static String[] mergeStringArrays(String[] n, String[] f){
        String[] q = new String[n.length + f.length];
        int numDiff = 0;
        if(n.length > 0) {
            for (int i = 0; i < n.length; i++) {
                q[i] = n[i];
            }
            numDiff = n.length;
        }
        if(f.length > 0) {
            for (int i = 0; i < f.length; i++) {
                q[i + numDiff] = f[i];
            }
        }
        return q;
    }
    public static boolean exists(String f, String[] n){
        for(String i:n){
            if(f.equals(i))
                return true;
        }
        return false;
    }
    public static int indexOf(String f, String[] n){
        for(int i = 0; i < n.length; i++){
            if(f.equals(n[i]))
                return i;
        }
        return -1;
    }

    public static int[] stretchIntArray(int[] arr){
        int[] f = new int[arr.length * 2 + 1];
        for(int i = 0; i < arr.length; i++){
            f[i] = arr[i];
        }
        return f;
    }
    public static String[] stretchStringArray(String[] arr){
        String[] f = new String[arr.length * 2 + 1];
        for(int i = 0; i < arr.length; i++){
            f[i] = arr[i];
        }
        return f;
    }
}
