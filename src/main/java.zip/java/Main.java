import enchants.ElementalDamageEffect;
import enchants.Enchantment;
import people.*;
import items.*;
import dieRolling.*;
import tools.*;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    private static Scanner jin = new Scanner(System.in);
    public static void main(String[] args) throws IOException {
        genRandoms(1000);
    }
    public static void genRandoms(int number) throws IOException {
        for(int i = 0; i < number; i++) {
            NPC example = new NPC("Random NPC", "A randbob", "Level 0 Rando", "Human");
            example.randomRace(Races.genTiers(true, true, true, true, true, true));
            example.setType("Level 0 " + example.getRace());
            ChargenLog.logWithTime(example.toString());
        }
    }
    public static void genRandoms(int number, boolean broken) throws IOException {
        for(int i = 0; i < number; i++) {
            NPC example = new NPC("Random NPC", "A randbob", "Level 0 Rando", "Human");
            example.randomRace(Races.genTiers(true, true, true, true, true, true));
            example.setType("Level 0 " + example.getRace());
            if(broken){
                example.randomStatsPowerful();
            }
            ChargenLog.logWithTime(example.toString());
        }
    }

    public static void genSpecificRace(String race, int number) throws IOException{
        for(int i = 0; i < number; i++) {
            NPC example = new NPC("Random " + race, "A random " + race, "Level 0 " + race, race);
            ChargenLog.logWithTime(example.toString());
        }
    }
    public static void genSpecificRace(String race, int number, boolean broken) throws IOException{
        for(int i = 0; i < number; i++) {
            NPC example = new NPC("Random " + race, "A random " + race, "Level 0 " + race, race);
            if(broken){
                example.randomStatsPowerful();
            }
            ChargenLog.logWithTime(example.toString());
        }
    }

    public static void genValbs (int chestTier, int rollBonus, int number) throws IOException {
        for(int i = 0; i < number; i++){
            ChargenLog.logWithTime(LootGenerator.valuablesGen(chestTier, rollBonus).toString());
        }
    }

    public static int menu() throws IOException {
        boolean operating = true;
        while(operating){
            System.out.println("" +
                    " 1) Random people.NPC\n" +
                    "-1) Quit");
            int opt = jin.nextInt();
            jin.nextLine();
            if(opt == 1){
                System.out.println("1) Include name\n" +
                        "2) Include name & desc\n" +
                        "3) Include name, desc and class\n" +
                        "4) Include name, desc, class and race\n" +
                        "5) No details (Default person)\n");
                opt = jin.nextInt();
                jin.nextLine();
                NPC generated = new NPC();
                if(opt == 1) {
                    System.out.print("Name:");
                    System.out.flush();
                    String name = jin.nextLine();
                    generated = new NPC(name);
                }
                else if(opt == 2){
                    System.out.print("Name:");
                    String name = jin.nextLine();
                    System.out.print("Desc:");
                    String desc = jin.nextLine();
                    generated = new NPC(name, desc);
                }
                System.out.println(generated.toString());
                ChargenLog.logWithTime(generated.toString());
            }
            else if(opt == -1)
                operating = false;
        }
        return -1;
    }
}
