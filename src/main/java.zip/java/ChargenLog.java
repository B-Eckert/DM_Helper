import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class ChargenLog {
    private static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    private static LocalDateTime now = LocalDateTime.now();
    public static void ensureFile() throws IOException {
        Path p = Paths.get(FILE_NAME);
        try{
            Files.readAllLines(p);
        } catch (NoSuchFileException e){
            File n = new File(FILE_NAME);
            n.createNewFile();
            now = LocalDateTime.now();
            log("File created at " + dtf.format(now));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static List<String> tryReadingShort() throws IOException {
        ensureFile();
        Path p = Paths.get(FILE_NAME);
        return Files.readAllLines(p);
    }
    public static void tryWritingShort(List<String> lines) throws IOException {
        ensureFile();
        Path p = Paths.get(FILE_NAME);
        List<String> n = tryReadingShort();
        List<String> artifact = new ArrayList<>();
        while(!n.isEmpty()){
            artifact.add(n.remove(0));
        }
        while(!lines.isEmpty()) {
            artifact.add(lines.remove(0));
        }
        Files.write(p, artifact);
    }
    public static void log(String log) throws IOException {
        List<String> n = new ArrayList<>();
        n.add(log);
        n.add("-------------------------------------------");
        tryWritingShort(n);
    }
    public static void logWithTime(String inLog) throws IOException{
        log("Entry made at " + dtf.format(now));
        log(inLog);
    }
    public static void print() throws IOException{
        List<String> n = tryReadingShort();
        while(!n.isEmpty()){
            System.out.println(n.remove(0));
        }
    }

    final static Charset ENCODING = StandardCharsets.UTF_8;
    final static String FILE_NAME = System.getProperty("user.home") + "\\Desktop\\D&DProgShit\\chargenlog.txt";
}
